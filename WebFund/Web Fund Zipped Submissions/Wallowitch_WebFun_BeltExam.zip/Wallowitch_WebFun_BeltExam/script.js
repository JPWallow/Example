function changeImg(element){
    element.src = "images/assets/succulents-2.jpg"
};

function fixImg(element){
    element.src = "images/assets/succulents-1.jpg"
};

function hide(div){    
div.remove() 
}