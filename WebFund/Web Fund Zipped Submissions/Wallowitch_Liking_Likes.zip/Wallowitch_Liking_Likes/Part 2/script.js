var likeNeil = 9;
var neilElement = document.querySelector("#likeNeil");


function addNeil(){
    likeNeil++;
    neilElement.innerText = likeNeil;
}

var likeNichole = 12;
var nicholeElement = document.querySelector("#likeNichole");


function addNichole(){
    likeNichole++;
    nicholeElement.innerText = likeNichole;
}

var likeJim = 9;
var jimElement = document.querySelector("#likeJim");


function addJim(){
    likeJim++;
    jimElement.innerText = likeJim;
}