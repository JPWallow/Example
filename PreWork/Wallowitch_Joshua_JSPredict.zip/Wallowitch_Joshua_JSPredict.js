//Predict 1: console.log will state "I was born in 1980"
//Predict 2: Again console.log would state "I was born in 1980"
//Predict 3: The console.log would state "30"